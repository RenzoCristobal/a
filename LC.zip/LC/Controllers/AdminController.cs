﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LC.Controllers
{
    [Authorize]
    public class AdminController : Controller
    {
        public IActionResult Index()
        {
            return View("Admin"); // Asegúrate de tener la vista en Views/Admin
        }

        public IActionResult ManageMenu()
        {
            return View(); // Asegúrate de tener la vista en Views/Admin/ManageMenu.cshtml
        }

        public IActionResult ViewOrders()
        {
            return View(); // Asegúrate de tener la vista en Views/Admin/ViewOrders.cshtml
        }

        public IActionResult Promotions()
        {
            return View(); // Asegúrate de tener la vista en Views/Admin/Promotions.cshtml
        }
    }
}
