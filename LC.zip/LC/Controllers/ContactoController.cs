﻿using Microsoft.AspNetCore.Mvc;
using LC.Models;

namespace LC.Controllers
{
    public class ContactoController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ContactoController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Submit(ContactFormModel model)
        {
            if (ModelState.IsValid)
            {
                _context.ContactFormMessages.Add(model);
                _context.SaveChanges();
                return RedirectToAction("ThankYou");
            }

            return View("Index", model);
        }

        public IActionResult ThankYou()
        {
            return View(); // Asegúrate de tener la vista en Views/Contacto/ThankYou.cshtml
        }
    }
}
