﻿using Microsoft.AspNetCore.Mvc;

namespace LC.Controllers
{
    public class NoticiasController : Controller
    {
        public IActionResult Index()
        {
            return View(); // Asegúrate de tener la vista en Views/Noticias/Index.cshtml
        }
    }
}
