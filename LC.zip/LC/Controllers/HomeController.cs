using Microsoft.AspNetCore.Mvc;

namespace LC.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Promociones()
        {
            return View();
        }

        public IActionResult Noticias()
        {
            return View();
        }

        public IActionResult Contacto()
        {
            return View();
        }

        public IActionResult Error()
        {
            return View();
        }
    }
}
