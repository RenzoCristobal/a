﻿using Microsoft.AspNetCore.Mvc;

namespace LC.Controllers
{
    public class PromocionesController : Controller
    {
        public IActionResult Index()
        {
            return View(); // Asegúrate de tener la vista en Views/Promociones/Index.cshtml
        }
    }
}
