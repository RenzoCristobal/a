﻿// Aquí puedes agregar JavaScript para interactividad en tu sitio web

document.addEventListener("DOMContentLoaded", function () {
    // Ejemplo de un alert en el formulario de contacto
    const contactForm = document.querySelector('.contact-form');
    contactForm.addEventListener('submit', function (e) {
        e.preventDefault();
        alert('Gracias por tu mensaje! Nos pondremos en contacto contigo pronto.');
        contactForm.reset(); // Limpia el formulario
    });
});
